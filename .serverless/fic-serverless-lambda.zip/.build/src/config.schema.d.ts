/// <reference types="hapi__joi" />
import * as Joi from '@hapi/joi';
export declare const configValidationSchema: Joi.ObjectSchema<any>;
