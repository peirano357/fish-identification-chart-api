export declare class PurchasesModule {
}
