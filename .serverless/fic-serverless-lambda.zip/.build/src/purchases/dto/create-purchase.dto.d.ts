export declare class CreatePurchaseDto {
    purchasedDate: Date;
    userId: string;
    regionId: string;
}
