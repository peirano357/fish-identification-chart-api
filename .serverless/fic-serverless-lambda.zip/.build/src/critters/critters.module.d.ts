export declare class CrittersModule {
}
