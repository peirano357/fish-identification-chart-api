export declare class Critter {
    id: string;
    name: string;
    description: string;
    imageUrl: string;
    constructor(name?: string, description?: string, imageUrl?: string);
}
