export declare class UpdateCritterDto {
    name: string;
    description: string;
    imageUrl: string;
}
