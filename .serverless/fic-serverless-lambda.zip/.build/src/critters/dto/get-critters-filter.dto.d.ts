export declare class GetCritterFilterDto {
    search?: string;
}
