export declare class CreateCritterDto {
    name: string;
    description: string;
    imageUrl: string;
}
