export declare class CreateSpotDto {
    spottedDate: Date;
    userId: string;
    critterId: string;
    latitude: number;
    longitude: number;
}
