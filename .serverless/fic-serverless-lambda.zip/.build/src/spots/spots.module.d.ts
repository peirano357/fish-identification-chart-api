export declare class SpotsModule {
}
