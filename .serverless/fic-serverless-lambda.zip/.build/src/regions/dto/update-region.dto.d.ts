export declare class UpdateRegionDto {
    name: string;
    description: string;
    imageUrl: string;
}
