export declare class CreateRegionDto {
    name: string;
    description: string;
    imageUrl: string;
}
