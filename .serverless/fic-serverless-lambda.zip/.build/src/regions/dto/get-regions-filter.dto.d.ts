export declare class GetRegionsFilterDto {
    search?: string;
}
