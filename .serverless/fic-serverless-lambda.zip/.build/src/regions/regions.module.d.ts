export declare class RegionsModule {
}
