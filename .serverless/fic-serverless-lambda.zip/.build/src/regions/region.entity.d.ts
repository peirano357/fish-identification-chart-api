export declare class Region {
    id: string;
    name: string;
    description: string;
    imageUrl: string;
    constructor(name?: string, description?: string, imageUrl?: string);
}
