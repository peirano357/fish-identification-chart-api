export declare class CrittersRegionsModule {
}
