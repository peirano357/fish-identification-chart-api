export declare class CreateCritterRegionDto {
    sort: number;
    critterId: string;
    regionId: string;
}
