export declare enum UserTypeEnum {
    administrator = "administrator",
    customer = "customer"
}
