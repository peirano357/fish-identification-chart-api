"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserTypeEnum = void 0;
var UserTypeEnum;
(function (UserTypeEnum) {
    UserTypeEnum["administrator"] = "administrator";
    UserTypeEnum["customer"] = "customer";
})(UserTypeEnum = exports.UserTypeEnum || (exports.UserTypeEnum = {}));
//# sourceMappingURL=user-type.enum.js.map