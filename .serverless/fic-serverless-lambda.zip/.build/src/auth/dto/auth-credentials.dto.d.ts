import { UserTypeEnum } from '../enum/user-type.enum';
export declare class AuthCredentialsDto {
    username: string;
    password: string;
    userType: UserTypeEnum;
}
