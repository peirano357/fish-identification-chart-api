export enum UserTypeEnum {
  administrator = 'administrator',
  customer = 'customer',
}
