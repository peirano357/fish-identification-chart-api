import { Body, Controller, Post } from '@nestjs/common';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthService } from './auth.service';
import { AuthCredentialsDto } from './dto/auth-credentials.dto';
import { User } from './user.entity';

@Controller('auth')
@ApiTags('Users')
export class AuthController {
  constructor(private authService: AuthService) {}
  @ApiOperation({
    summary: 'Creates a new user in the database.',
  })
  @ApiResponse({
    status: 201,
    description: 'User successfully created',
    type: User,
    isArray: false,
  })
  @Post('/signup')
  signUp(@Body() authCredentialsDto: AuthCredentialsDto): Promise<User> {
    return this.authService.signUp(authCredentialsDto);
  }

  @Post('/signin')
  @ApiOperation({
    summary: 'Logs in a user and creates a valid JWT for further API calls.',
  })
  signIn(
    @Body() authCredentialsDto: AuthCredentialsDto,
  ): Promise<{ accessToken: string }> {
    return this.authService.signIn(authCredentialsDto);
  }
}
